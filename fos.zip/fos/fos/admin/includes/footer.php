<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Food Ordering System desinged by Md. Tanvir Islam &copy;<?php echo date('Y');?>
            </div>
        </div>